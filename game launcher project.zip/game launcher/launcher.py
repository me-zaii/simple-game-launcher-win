import hashlib
import json
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
  from PIL import Image, ImageTk

  HAS_PIL = True
except ImportError:
  HAS_PIL = False

try:
  from icoextract import IconExtractor

  HAS_ICOEXTRACT = True
except ImportError:
  HAS_ICOEXTRACT = False

try:
  from tkinterdnd2 import DND_FILES, TkinterDnD

  HAS_DND = True
except ImportError:
  HAS_DND = False

DATA_FILE = "games_data.json"
ICONS_DIR = "cache_icons"


def crop_image_to_square(image):
  width, height = image.size
  min_side = min(width, height)
  left = (width - min_side) / 2
  top = (height - min_side) / 2
  right = (width + min_side) / 2
  bottom = (height + min_side) / 2
  return image.crop((left, top, right, bottom))


def extract_icon_from_path(path):
  if not path or not os.path.exists(path):
    return None
  ext = os.path.splitext(path)[1].lower()

  if not os.path.exists(ICONS_DIR):
    os.makedirs(ICONS_DIR)

  # Extração automática usando icoextract para executáveis (.exe)
  if ext == ".exe" and HAS_ICOEXTRACT:
    try:
      file_hash = hashlib.md5(path.encode("utf-8")).hexdigest()
      ico_path = os.path.join(ICONS_DIR, f"{file_hash}.ico")

      if not os.path.exists(ico_path):
        extractor = IconExtractor(path)
        extractor.export_icon(ico_path)

      if os.path.exists(ico_path) and HAS_PIL:
        return Image.open(ico_path)
    except Exception as e:
      print(f"Erro ao extrair ícone com icoextract: {e}")

  # Fallback para imagens ou arquivos de ícone direto (.ico, .png, etc.)
  if HAS_PIL:
    try:
      return Image.open(path)
    except Exception as e:
      print(f"Erro ao abrir imagem: {e}")

  return None


class GameLauncherApp:

  def __init__(self, root):
    self.root = root
    self.root.title("Game Launcher Pro - Steam Grid Style")
    self.root.geometry("850x580")
    self.root.minsize(650, 480)

    self.setup_styles()

    self.data = self.load_data()
    self.icons_cache = {}
    self.selected_game_path = None
    self.selected_card_frame = None

    self.notebook = ttk.Notebook(root)
    self.notebook.pack(fill="both", expand=True, padx=12, pady=12)
    self.notebook.bind("<<NotebookTabChanged>>", self.on_tab_change)

    self.create_context_menus()

    self.tabs = {}
    self.refresh_ui()

    if HAS_DND:
      try:
        self.root.drop_target_register(DND_FILES)
        self.root.dnd_bind("<<Drop>>", self.handle_file_drop)
      except Exception as e:
        print(f"Erro ao ativar Drag and Drop: {e}")

  def setup_styles(self):
    style = ttk.Style()
    style.theme_use("clam")

    bg_dark = "#121212"
    text_light = "#e0e0e0"
    accent_color = "#2a2a2a"
    select_color = "#00adb5"

    self.root.configure(bg=bg_dark)

    style.configure(".", background=bg_dark, foreground=text_light)
    style.configure("Dark.TFrame", background=bg_dark, foreground=text_light)
    style.configure(
        "TNotebook", background=bg_dark, borderwidth=0, tabmargins=[2, 5, 2, 0]
    )
    style.configure(
        "TNotebook.Tab",
        background=accent_color,
        foreground=text_light,
        padding=[12, 6],
        font=("Segoe UI", 9, "bold"),
    )
    style.map(
        "TNotebook.Tab",
        background=[("selected", select_color)],
        foreground=[("selected", "#ffffff")],
    )

  def create_context_menus(self):
    self.game_menu = tk.Menu(
        self.root,
        tearoff=0,
        bg="#1e1e1e",
        fg="#e0e0e0",
        activebackground="#00adb5",
        activeforeground="#ffffff",
        font=("Segoe UI", 9),
    )
    self.game_menu.add_command(
        label="🚀 Iniciar Jogo", command=self.launch_selected_game
    )
    self.game_menu.add_separator()
    self.game_menu.add_command(
        label="🏆 Alternar Zerado", command=self.toggle_completed
    )
    self.game_menu.add_command(
        label="🖼️ Alterar Ícone", command=self.change_icon_manual
    )
    self.game_menu.add_separator()
    self.game_menu.add_command(
        label="🗑️ Remover Jogo", command=self.remove_game
    )

    self.bg_menu = tk.Menu(
        self.root,
        tearoff=0,
        bg="#1e1e1e",
        fg="#e0e0e0",
        activebackground="#00adb5",
        activeforeground="#ffffff",
        font=("Segoe UI", 9),
    )
    self.bg_menu.add_command(
        label="📁 Adicionar Jogo", command=self.add_game
    )
    self.bg_menu.add_command(
        label="➕ Nova Categoria", command=self.add_category
    )
    self.bg_menu.add_separator()
    self.bg_menu.add_command(
        label="🗑️ Remover Categoria Atual", command=self.remove_category
    )

  def load_data(self):
    if os.path.exists(DATA_FILE):
      try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
          return json.load(f)
      except:
        pass
    return {"PC Games": []}

  def save_data(self):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
      json.dump(self.data, f, ensure_ascii=False, indent=4)

  def on_tab_change(self, event):
    self.selected_game_path = None
    self.selected_card_frame = None

  def refresh_ui(self):
    for tab_id in self.notebook.tabs():
      self.notebook.forget(tab_id)

    self.tabs.clear()
    self.icons_cache.clear()
    self.selected_game_path = None
    self.selected_card_frame = None

    if not self.data:
      self.data = {"PC Games": []}

    for category in self.data.keys():
      main_frame = ttk.Frame(self.notebook, style="Dark.TFrame")
      self.notebook.add(main_frame, text=category)
      self.tabs[category] = main_frame

      canvas = tk.Canvas(main_frame, bg="#121212", highlightthickness=0)
      scrollbar = ttk.Scrollbar(
          main_frame, orient="vertical", command=canvas.yview
      )
      scrollable_frame = ttk.Frame(canvas, style="Dark.TFrame")

      scrollable_frame.bind(
          "<Configure>",
          lambda e: canvas.configure(scrollregion=canvas.bbox("all")),
      )
      canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
      canvas.configure(yscrollcommand=scrollbar.set)

      def _on_mouse_wheel(event):
        canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

      canvas.bind_all("<MouseWheel>", _on_mouse_wheel)

      canvas.bind(
          "<Button-3>", lambda e: self.bg_menu.tk_popup(e.x_root, e.y_root)
      )
      scrollable_frame.bind(
          "<Button-3>", lambda e: self.bg_menu.tk_popup(e.x_root, e.y_root)
      )

      canvas.pack(side="left", fill="both", expand=True, padx=5, pady=5)
      scrollbar.pack(side="right", fill="y", pady=5)

      games = self.data[category]
      max_cols = 4

      for idx, game in enumerate(games):
        row = idx // max_cols
        col = idx % max_cols

        card = self.create_game_card(scrollable_frame, game, category)
        card.grid(row=row, column=col, padx=12, pady=12, sticky="nsew")

  def create_game_card(self, parent, game, category):
    card_bg = "#1e1e1e"
    card = tk.Frame(parent, bg=card_bg, width=165, height=210, relief="flat")
    card.pack_propagate(False)

    def select_and_show_menu(e):
      self.highlight_card(card, game["path"])
      self.game_menu.tk_popup(e.x_root, e.y_root)

    def launch(e):
      self.highlight_card(card, game["path"])
      self.launch_selected_game()

    card.bind("<Button-1>", lambda e: self.highlight_card(card, game["path"]))
    card.bind("<Button-3>", select_and_show_menu)
    card.bind("<Double-Button-1>", launch)

    img = self.load_icon_image(game)

    img_container = tk.Frame(card, bg="#252525", width=135, height=135)
    img_container.pack_propagate(False)
    img_container.pack(padx=15, pady=(12, 6))

    img_label = tk.Label(
        img_container, bg="#252525", cursor="hand2", relief="flat"
    )
    img_label.pack(fill="both", expand=True)

    if img:
      img_label.config(image=img)
    else:
      img_label.config(
          text="🎮\nSem Ícone", fg="#888888", font=("Segoe UI", 9, "bold")
      )

    img_label.bind(
        "<Button-1>", lambda e: self.highlight_card(card, game["path"])
    )
    img_label.bind("<Button-3>", select_and_show_menu)
    img_label.bind("<Double-Button-1>", launch)
    img_container.bind(
        "<Button-1>", lambda e: self.highlight_card(card, game["path"])
    )
    img_container.bind("<Button-3>", select_and_show_menu)
    img_container.bind("<Double-Button-1>", launch)

    info_frame = tk.Frame(card, bg=card_bg)
    info_frame.pack(fill="x", padx=10, expand=True)
    info_frame.bind(
        "<Button-1>", lambda e: self.highlight_card(card, game["path"])
    )
    info_frame.bind("<Button-3>", select_and_show_menu)

    is_completed = game.get("completed", False)
    trophy_text = "🏆 " if is_completed else ""

    name_label = tk.Label(
        info_frame,
        text=trophy_text + game["name"],
        bg=card_bg,
        fg="#e0e0e0",
        font=("Segoe UI", 9, "bold"),
        anchor="w",
        wraplength=140,
    )
    name_label.pack(side="left", fill="x", expand=True)
    name_label.bind(
        "<Button-1>", lambda e: self.highlight_card(card, game["path"])
    )
    name_label.bind("<Button-3>", select_and_show_menu)

    return card

  def highlight_card(self, card, path):
    if self.selected_card_frame and self.selected_card_frame.winfo_exists():
      try:
        self.selected_card_frame.config(bg="#1e1e1e")
      except:
        pass
    self.selected_card_frame = card
    card.config(bg="#333333")
    self.selected_game_path = path

  def load_icon_image(self, game):
    icon_path = game.get("icon", "")
    if not icon_path or not os.path.exists(icon_path):
      icon_path = game.get("path", "")

    if icon_path and os.path.exists(icon_path):
      if icon_path in self.icons_cache:
        return self.icons_cache[icon_path]

      pil_img = extract_icon_from_path(icon_path)
      if pil_img and HAS_PIL:
        pil_img = crop_image_to_square(pil_img)
        pil_img = pil_img.resize((125, 125), Image.Resampling.LANCZOS)
        img = ImageTk.PhotoImage(pil_img)
        self.icons_cache[icon_path] = img
        return img
    return None

  def get_current_category(self):
    try:
      current_tab_idx = self.notebook.index(self.notebook.select())
      categories = list(self.data.keys())
      return categories[current_tab_idx]
    except:
      return "PC Games"

  def add_game(self):
    cat = self.get_current_category()
    file_path = filedialog.askopenfilename(
        title="Selecionar Jogo ou Atalho",
        filetypes=[
            ("Executáveis e Atalhos", "*.exe *.lnk *.url"),
            ("Todos os Ficheiros", "*.*"),
        ],
    )
    if file_path:
      self.process_added_file(file_path, cat)

  def handle_file_drop(self, event):
    cat = self.get_current_category()
    files = self.root.tk.splitlist(event.data)
    for file_path in files:
      if os.path.exists(file_path):
        self.process_added_file(file_path, cat)

  def process_added_file(self, file_path, category):
    name = os.path.splitext(os.path.basename(file_path))[0]
    exists = any(g["path"] == file_path for g in self.data[category])
    if not exists:
      self.data[category].append({
          "name": name,
          "path": file_path,
          "icon": "",
          "completed": False,
      })
      self.save_data()
      self.refresh_ui()

  def add_category(self):
    top = tk.Toplevel(self.root)
    top.title("Nova Categoria")
    top.geometry("320x140")
    top.resizable(False, False)
    top.configure(bg="#1e1e1e")

    ttk.Label(
        top,
        text="Nome da Categoria:",
        foreground="#e0e0e0",
        background="#1e1e1e",
    ).pack(padx=10, pady=10)
    entry = ttk.Entry(top, width=32)
    entry.pack(padx=10)
    entry.focus()

    def save_cat():
      cat_name = entry.get().strip()
      if cat_name and cat_name not in self.data:
        self.data[cat_name] = []
        self.save_data()
        self.refresh_ui()
        top.destroy()
      elif cat_name in self.data:
        messagebox.showerror("Erro", "Essa categoria já existe!")

    save_btn = tk.Button(
        top,
        text="Criar Categoria",
        command=save_cat,
        bg="#00adb5",
        fg="#ffffff",
        bd=0,
        font=("Segoe UI", 9, "bold"),
        padx=10,
        pady=5,
    )
    save_btn.pack(pady=12)

  def remove_category(self):
    cat = self.get_current_category()
    if len(self.data) <= 1:
      messagebox.showwarning(
          "Aviso", "Você não pode remover a última categoria restante!"
      )
      return

    if messagebox.askyesno(
        "Confirmar Exclusão",
        f"Tem certeza que deseja remover a categoria '{cat}' e todos os jogos"
        " nela?",
    ):
      del self.data[cat]
      self.save_data()
      self.refresh_ui()

  def launch_selected_game(self):
    if not self.selected_game_path:
      messagebox.showwarning(
          "Aviso", "Selecione um jogo na grade primeiro."
      )
      return
    try:
      os.startfile(self.selected_game_path)
    except Exception as ex:
      messagebox.showerror("Erro", f"Não foi possível abrir o ficheiro:\n{ex}")

  def toggle_completed(self):
    cat = self.get_current_category()
    if not self.selected_game_path:
      messagebox.showwarning(
          "Aviso", "Selecione um jogo na grade primeiro."
      )
      return

    for game in self.data[cat]:
      if game["path"] == self.selected_game_path:
        game["completed"] = not game.get("completed", False)
        break

    self.save_data()
    self.refresh_ui()

  def change_icon_manual(self):
    cat = self.get_current_category()
    if not self.selected_game_path:
      messagebox.showwarning(
          "Aviso", "Selecione um jogo na grade primeiro."
      )
      return

    icon_path = filedialog.askopenfilename(
        title="Selecionar Ícone de Qualquer Diretório",
        filetypes=[
            (
                "Imagens, Ícones e Executáveis",
                "*.png *.jpg *.jpeg *.ico *.gif *.exe",
            ),
            ("Todos os Ficheiros", "*.*"),
        ],
    )
    if icon_path:
      for game in self.data[cat]:
        if game["path"] == self.selected_game_path:
          game["icon"] = icon_path
          break

      self.save_data()
      self.refresh_ui()

  def remove_game(self):
    cat = self.get_current_category()
    if not self.selected_game_path:
      messagebox.showwarning(
          "Aviso", "Selecione um jogo na grade primeiro."
      )
      return

    self.data[cat] = [
        g for g in self.data[cat] if g["path"] != self.selected_game_path
    ]
    self.save_data()
    self.refresh_ui()


if __name__ == "__main__":
  if HAS_DND:
    root = TkinterDnD.Tk()
  else:
    root = tk.Tk()
  app = GameLauncherApp(root)
  root.mainloop()